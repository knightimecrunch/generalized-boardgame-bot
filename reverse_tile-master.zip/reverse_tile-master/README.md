reverse tile game
=======

Reverse tile game programmed with kivy

Will work on :
- Windows xp and more 
- Linux
- Raspberry PI
- Android : published on Google Play  (not anymore due to legal concerns, othello and reversi are copyrighted then it was not a good idea to name the game with those trademarks, gargl )
- Mac 


Last changes:
- added resume game

Todo :
- add hint
- make a decent interface with kv file
- clean code, weird things and bad english
- improve computer AI
- display score with player indication
- add translation file

Kivy is a great Framework, use it today :)
